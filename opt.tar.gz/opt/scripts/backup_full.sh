
HELP_FILE="/opt/scripts/help.txt"

#Si el primer argumento es -help, muestra la ayuda.
#Despues verifica que exista el archivo help y si existe lo muestr (cat), si  no, manda mensaje

#Exit 1 inidica que el script terminó con errores
#Exit 0 indica que el script terminó correctamente y sin errores

if [ "$1" == "-help" ]; then
	if [ -f "$HELP_FILE" ]; then
		cat "$HELP_FILE"
	else
		echo "Archivo de ayuda no encontrado en $HELP_FILE"
	fi
	exit 0
fi

#Valida que los argumentos enviados al citar citar el script sean 2 (origen y destino)
#Si no, manda un mensaje de error
	#$#: representa la cantidad de argumentos que le pasamos al script
	#-ne: "not equal#, significa distinto de.

if [ $# -ne 2 ]; then
	echo "Error: Se requieren 2 argumentos (origen y destino). Use -help para más información"
	exit 1
fi

#Valida que existan los directorios de origen y destino
#Si alguno no existe (o los dos) muestra error

	#-d:determina si lo que pasamos es un directorio válido
	#!: negación 

if [ ! -d "$1" ]; then
	echo "Error: Directorio de origen '$1' no existe."
	exit 1
elif [ ! -d "$2" ]; then
	echo "Error: Directorio de destino '$2' no existe."
fi

#Definir fecha en formato ANSI
	#date: comando para obtener fecha y hora del sistema
	#%Y: año con 4 digitos (ejemplos: 2003)
	#%m: mes con 2 digitos (ejeplos:07)
	#%d: dia con 2 digitos (ejemplo:15)

FECHA=$(date +%Y%m%d)
#Trae solo el nombre del archivo de origen (argumento $1) sin aclarar la ruta

NOMBRE_ORIGEN=$(basename "$1")
#Construye el nombre del archivo de backup

BACKUP="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"
#Crea un archivo comprimido .tar.gz
	#tar: Comando para empaquetar archivo
	#-c: crea un archivo
	#-z: comprime usando gzip
	#-f: especifica el nombre del archivo de salida
	#-C: "$1: cambia el directorio origen
	#. (punto): significa que se comprimen todos los archivos del origen 
	#Se guarda en la ruta destino (argumento $2) con el nombre $BACKUP.

#Acá pone todo tal cual está, el punto incluido

tar -czf "$2/$BACKUP" -C "$1" .

#Verifica si el archivo se creó correctamente. Si no, envia un mensaje de error
	#-f: evalúa si existe un archivo regular 

if [ -f "$2/$BACKUP" ]; then
	echo "Backup creado exitosamente: $2/$BACKUP"
else
	echo "Error: No se pudo crear el backup"
	exit 1
fi


















